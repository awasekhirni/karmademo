module.exports=function(grunt){
//project configurations
grunt.initConfig({
    pkg:grunt.file.readJSON('package.json'),
    karma:{
        unit:{
            configFile:'./karma.conf.js'
        }
    }
});

grunt.loadNpmTasks('grunt-karma');
//grunt.loadNpmTasks('grunt-jasmine-coverage');
//defaultl tasks
grunt.registerTask('default',['karma']);

};