module.exports = function(config) {
    config.set({
      // base path, that will be used to resolve files and exclude
      basePath: '',
        //frameworks to use
      frameworks: ['jasmine'],
  
      // list of files / patterns to load in the browser
      files: [
          {pattern:'./src/**/*.js',included:true},
          {pattern:'./spec/**/*.js',included:true},
          {pattern:'./spec/*Spec.js',included:true},
            ],
  
      // list of files to exclude
      exclude: [],
  
      // use dots reporter, as travis terminal does not support escaping sequences
      // possible values: 'dots', 'progress',junit,growl,coverage
      reporters: ['progress', 'junit'],
  
  // will be resolved to basePath (in the same way as files/exclude patterns)	
  junitReporter: {outputFile: 'test-results.xml'},
  
      // web server port
      port: 9876,
  
      // enable / disable colors in the output (reporters and logs)
      colors: true,
  
      // level of logging
      // possible values: config.LOG_DISABLE || config.LOG_ERROR || config.LOG_WARN || config.LOG_INFO || config.LOG_DEBUG
      logLevel: config.LOG_INFO,
  
      // enable / disable watching file and executing tests whenever any file changes
      autoWatch: true,
  
      // Start these browsers, currently available:
      // - Chrome, ChromeCanary, Firefox, Opera, Safari (only Mac), PhantomJS, IE (only Windows)
      //   // available browser launchers: https://npmjs.org/browse/keyword/karma-launcher
//
     // browsers: [process.env.TRAVIS ? 'Firefox' : 'Chrome'],
     browsers: ['Chrome', 'PhantomJS','Firefox','Opera'],

    //   customLaunchers:{
    //       chrome_without_security:{
    //           base:"Chrome",
    //           flags:["--disable-web-security"]
    //       }
    //   }
  
      // If browser does not capture in given timeout [ms], kill it
      captureTimeout: 20000,
  
      // Auto run tests on start (when browsers are captured) and exit
      singleRun: false,
  
      // report which specs are slower than 500ms
      reportSlowerThan: 500,
  
      // compile coffee scripts
     // preprocessors: {'**/*.coffee': 'coffee'},
     preprocessors: {
    },

     concurrency: Infinity,
  
      plugins: ['karma-jasmine','karma-chrome-launcher',
      'karma-firefox-launcher','karma-junit-reporter','karma-opera-launcher','karma-phantomjs-launcher']
    });
  };